<?php
include('db.php');

function calculateBill($units)
{
    $bill = 0;
    if ($units <= 50) {
        $bill = $units * 3.50;
    } else if ($units > 50 && $units <= 150) {
        $bill = (50 * 3.50) + (($units - 50) * 4.00);
    } else if ($units > 150 && $units <= 250) {
        $bill = (50 * 3.50) + (100 * 4.00) + (($units - 150) * 5.20);
    } else {
        $bill = (50 * 3.50) + (100 * 4.00) + (100 * 5.20) + (($units - 250) * 6.50);
    }
    return $bill;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $name = $_POST['name'];
    $user_id = $_POST['id'];
    $date = isset($_POST['date']) ? $_POST['date'] : NULL;
    $city = isset($_POST['city']) ? $_POST['city'] : NULL;
    $units = $_POST['units'];
    $month = isset($_POST['month']) ? $_POST['month'] : NULL;

    $bill = calculateBill($units);

    // Prepare and bind
    $stmt = $conn->prepare("INSERT INTO submissions (name, user_id, date, city, units, bill) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sisssd", $name, $user_id, $date, $city, $units, $bill);

    // Execute the statement
    if ($stmt->execute()) {
        echo "New record created successfully. <br> Calculated bill: Rs. " . number_format($bill, 2);
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();

    echo "<br>The electricity bill for $name for the month of $month, with a usage of $units units, is Rs. $bill";
}
?>
