const express = require("express")
const cors = require("cors");
const bodyParser = require("body-parser");

const app = express();

app.use(cors());
app.use(bodyParser.json())

const PORT = 5001;

app.listen(PORT, () => {
    console.log("server started")
})

app.post('/get-bill', (req, res) => {
    const { units } = req.body;
    if (!units) {
        return res.status(400).json({ bill: 'Amount is required' });
    }
    if (units < 0)
        return res.status(200).json({ bill: 0 });
    var bill = 0;
    if (units <= 50) {
        bill = units * 3.50;
    } else if (units <= 150) {
        bill = 50 * 3.50 + (units - 50) * 4.00;
    } else if (units <= 250) {
        bill = 50 * 3.50 + 100 * 4.00 + (units - 150) * 5.20;
    } else {
        bill = 50 * 3.50 + 100 * 4.00 + 100 * 5.20 + (units - 250) * 6.50;
    }
    return res.status(200).json({ bill });
})