import logo from "./logo.svg";
import "./App.css";
import React from "react";
import axios from "axios";

function App() {
  const [bill, setBill] = React.useState(0.0);
  const [units, setUnits] = React.useState(0.0);
  const getAnswer = async () => {
    const { data } = await axios.post("http://localhost:5001/get-bill", {
      units,
    });
    setBill(data.bill);
  };
  return (
    <div className="App">
      <div className="container mt-5">
        <h1 className="text-center text-primary">Calculate Electricity Bill</h1>
        <div id="bill-form">
          <div className="form-group">
            <input
              type="number"
              name="units"
              id="units"
              className="form-control"
              onChange={(e) => setUnits(e.target.value)}
              placeholder="Enter units"
            />
          </div>
          <button
            onClick={() => getAnswer()}
            name="unit-submit"
            id="unit-submit"
            className="btn btn-info center"
          >
            Calculate bill
          </button>
        </div>
        <div className="mt-3">
          <h3 id="result" className="text-center text-success">
            {bill} Rs
          </h3>
        </div>
      </div>
    </div>
  );
}

export default App;
