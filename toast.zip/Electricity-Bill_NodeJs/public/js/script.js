function calculateBill() {
  var units = parseInt($("#unitsInput").val());
  var rate = 0;

  if (units <= 50) {
    rate = 3.5;
  } else if (units <= 150) {
    rate = 4.0;
  } else if (units <= 250) {
    rate = 5.2;
  } else {
    rate = 6.5;
  }

  var totalBill = units * rate;

  $("#result").html(
    `<p>Your electricity bill is Rs. ${totalBill.toFixed(2)}</p>`
  );
}
