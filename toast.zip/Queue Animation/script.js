const queueContainer = document.getElementById("queue-container");
let lastEnqueuedElement = null;

function enqueue() {
  const input = document.getElementById("enqueue-input");
  const value = input.value.trim();
  if (value) {
    const element = document.createElement("div");
    element.className = "queue-element";
    element.textContent = value;
    queueContainer.appendChild(element);
    lastEnqueuedElement = element;
    input.value = "";
  } else {
    alert("Please enter a value");
  }
}

function dequeue() {
  if (lastEnqueuedElement) {
    lastEnqueuedElement.classList.add("upward");
    lastEnqueuedElement.addEventListener("transitionend", function () {
      queueContainer.removeChild(lastEnqueuedElement);
      lastEnqueuedElement = null;
      if (!queueContainer.firstElementChild) {
        resetQueue();
      }
    });
  } else {
    resetQueue();
  }
}

function resetQueue() {
  while (queueContainer.firstChild) {
    queueContainer.removeChild(queueContainer.firstChild);
  }
  alert("Queue is reset.");
}
